PIZZA SALES ANALYSIS


```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
import plotly.express as px
```

Import Raw Data


```python
df = pd.read_excel("pizza_sales_excel_file.xlsx")
```

MetaData of Raw Data


```python
df.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>pizza_id</th>
      <th>order_id</th>
      <th>pizza_name_id</th>
      <th>quantity</th>
      <th>order_date</th>
      <th>order_time</th>
      <th>unit_price</th>
      <th>total_price</th>
      <th>pizza_size</th>
      <th>pizza_category</th>
      <th>pizza_ingredients</th>
      <th>pizza_name</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>1</td>
      <td>hawaiian_m</td>
      <td>1</td>
      <td>2015-01-01</td>
      <td>11:38:36</td>
      <td>13.25</td>
      <td>13.25</td>
      <td>M</td>
      <td>Classic</td>
      <td>Sliced Ham, Pineapple, Mozzarella Cheese</td>
      <td>The Hawaiian Pizza</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>2</td>
      <td>classic_dlx_m</td>
      <td>1</td>
      <td>2015-01-01</td>
      <td>11:57:40</td>
      <td>16.00</td>
      <td>16.00</td>
      <td>M</td>
      <td>Classic</td>
      <td>Pepperoni, Mushrooms, Red Onions, Red Peppers,...</td>
      <td>The Classic Deluxe Pizza</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>2</td>
      <td>five_cheese_l</td>
      <td>1</td>
      <td>2015-01-01</td>
      <td>11:57:40</td>
      <td>18.50</td>
      <td>18.50</td>
      <td>L</td>
      <td>Veggie</td>
      <td>Mozzarella Cheese, Provolone Cheese, Smoked Go...</td>
      <td>The Five Cheese Pizza</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>2</td>
      <td>ital_supr_l</td>
      <td>1</td>
      <td>2015-01-01</td>
      <td>11:57:40</td>
      <td>20.75</td>
      <td>20.75</td>
      <td>L</td>
      <td>Supreme</td>
      <td>Calabrese Salami, Capocollo, Tomatoes, Red Oni...</td>
      <td>The Italian Supreme Pizza</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>2</td>
      <td>mexicana_m</td>
      <td>1</td>
      <td>2015-01-01</td>
      <td>11:57:40</td>
      <td>16.00</td>
      <td>16.00</td>
      <td>M</td>
      <td>Veggie</td>
      <td>Tomatoes, Red Peppers, Jalapeno Peppers, Red O...</td>
      <td>The Mexicana Pizza</td>
    </tr>
    <tr>
      <th>5</th>
      <td>6</td>
      <td>2</td>
      <td>thai_ckn_l</td>
      <td>1</td>
      <td>2015-01-01</td>
      <td>11:57:40</td>
      <td>20.75</td>
      <td>20.75</td>
      <td>L</td>
      <td>Chicken</td>
      <td>Chicken, Pineapple, Tomatoes, Red Peppers, Tha...</td>
      <td>The Thai Chicken Pizza</td>
    </tr>
    <tr>
      <th>6</th>
      <td>7</td>
      <td>3</td>
      <td>ital_supr_m</td>
      <td>1</td>
      <td>2015-01-01</td>
      <td>12:12:28</td>
      <td>16.50</td>
      <td>16.50</td>
      <td>M</td>
      <td>Supreme</td>
      <td>Calabrese Salami, Capocollo, Tomatoes, Red Oni...</td>
      <td>The Italian Supreme Pizza</td>
    </tr>
    <tr>
      <th>7</th>
      <td>8</td>
      <td>3</td>
      <td>prsc_argla_l</td>
      <td>1</td>
      <td>2015-01-01</td>
      <td>12:12:28</td>
      <td>20.75</td>
      <td>20.75</td>
      <td>L</td>
      <td>Supreme</td>
      <td>Prosciutto di San Daniele, Arugula, Mozzarella...</td>
      <td>The Prosciutto and Arugula Pizza</td>
    </tr>
    <tr>
      <th>8</th>
      <td>9</td>
      <td>4</td>
      <td>ital_supr_m</td>
      <td>1</td>
      <td>2015-01-01</td>
      <td>12:16:31</td>
      <td>16.50</td>
      <td>16.50</td>
      <td>M</td>
      <td>Supreme</td>
      <td>Calabrese Salami, Capocollo, Tomatoes, Red Oni...</td>
      <td>The Italian Supreme Pizza</td>
    </tr>
    <tr>
      <th>9</th>
      <td>10</td>
      <td>5</td>
      <td>ital_supr_m</td>
      <td>1</td>
      <td>2015-01-01</td>
      <td>12:21:30</td>
      <td>16.50</td>
      <td>16.50</td>
      <td>M</td>
      <td>Supreme</td>
      <td>Calabrese Salami, Capocollo, Tomatoes, Red Oni...</td>
      <td>The Italian Supreme Pizza</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.tail(15)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>pizza_id</th>
      <th>order_id</th>
      <th>pizza_name_id</th>
      <th>quantity</th>
      <th>order_date</th>
      <th>order_time</th>
      <th>unit_price</th>
      <th>total_price</th>
      <th>pizza_size</th>
      <th>pizza_category</th>
      <th>pizza_ingredients</th>
      <th>pizza_name</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>48605</th>
      <td>48606</td>
      <td>21345</td>
      <td>classic_dlx_s</td>
      <td>1</td>
      <td>2015-12-31</td>
      <td>20:44:43</td>
      <td>12.00</td>
      <td>12.00</td>
      <td>S</td>
      <td>Classic</td>
      <td>Pepperoni, Mushrooms, Red Onions, Red Peppers,...</td>
      <td>The Classic Deluxe Pizza</td>
    </tr>
    <tr>
      <th>48606</th>
      <td>48607</td>
      <td>21345</td>
      <td>spin_pesto_m</td>
      <td>1</td>
      <td>2015-12-31</td>
      <td>20:44:43</td>
      <td>16.50</td>
      <td>16.50</td>
      <td>M</td>
      <td>Veggie</td>
      <td>Spinach, Artichokes, Tomatoes, Sun-dried Tomat...</td>
      <td>The Spinach Pesto Pizza</td>
    </tr>
    <tr>
      <th>48607</th>
      <td>48608</td>
      <td>21346</td>
      <td>big_meat_s</td>
      <td>1</td>
      <td>2015-12-31</td>
      <td>20:51:07</td>
      <td>12.00</td>
      <td>12.00</td>
      <td>S</td>
      <td>Classic</td>
      <td>Bacon, Pepperoni, Italian Sausage, Chorizo Sau...</td>
      <td>The Big Meat Pizza</td>
    </tr>
    <tr>
      <th>48608</th>
      <td>48609</td>
      <td>21346</td>
      <td>cali_ckn_m</td>
      <td>1</td>
      <td>2015-12-31</td>
      <td>20:51:07</td>
      <td>16.75</td>
      <td>16.75</td>
      <td>M</td>
      <td>Chicken</td>
      <td>Chicken, Artichoke, Spinach, Garlic, Jalapeno ...</td>
      <td>The California Chicken Pizza</td>
    </tr>
    <tr>
      <th>48609</th>
      <td>48610</td>
      <td>21346</td>
      <td>cali_ckn_s</td>
      <td>1</td>
      <td>2015-12-31</td>
      <td>20:51:07</td>
      <td>12.75</td>
      <td>12.75</td>
      <td>S</td>
      <td>Chicken</td>
      <td>Chicken, Artichoke, Spinach, Garlic, Jalapeno ...</td>
      <td>The California Chicken Pizza</td>
    </tr>
    <tr>
      <th>48610</th>
      <td>48611</td>
      <td>21346</td>
      <td>soppressata_l</td>
      <td>1</td>
      <td>2015-12-31</td>
      <td>20:51:07</td>
      <td>20.75</td>
      <td>20.75</td>
      <td>L</td>
      <td>Supreme</td>
      <td>Soppressata Salami, Fontina Cheese, Mozzarella...</td>
      <td>The Soppressata Pizza</td>
    </tr>
    <tr>
      <th>48611</th>
      <td>48612</td>
      <td>21347</td>
      <td>bbq_ckn_m</td>
      <td>1</td>
      <td>2015-12-31</td>
      <td>21:14:37</td>
      <td>16.75</td>
      <td>16.75</td>
      <td>M</td>
      <td>Chicken</td>
      <td>Barbecued Chicken, Red Peppers, Green Peppers,...</td>
      <td>The Barbecue Chicken Pizza</td>
    </tr>
    <tr>
      <th>48612</th>
      <td>48613</td>
      <td>21347</td>
      <td>ital_supr_m</td>
      <td>1</td>
      <td>2015-12-31</td>
      <td>21:14:37</td>
      <td>16.50</td>
      <td>16.50</td>
      <td>M</td>
      <td>Supreme</td>
      <td>Calabrese Salami, Capocollo, Tomatoes, Red Oni...</td>
      <td>The Italian Supreme Pizza</td>
    </tr>
    <tr>
      <th>48613</th>
      <td>48614</td>
      <td>21347</td>
      <td>peppr_salami_s</td>
      <td>1</td>
      <td>2015-12-31</td>
      <td>21:14:37</td>
      <td>12.50</td>
      <td>12.50</td>
      <td>S</td>
      <td>Supreme</td>
      <td>Genoa Salami, Capocollo, Pepperoni, Tomatoes, ...</td>
      <td>The Pepper Salami Pizza</td>
    </tr>
    <tr>
      <th>48614</th>
      <td>48615</td>
      <td>21347</td>
      <td>southw_ckn_l</td>
      <td>1</td>
      <td>2015-12-31</td>
      <td>21:14:37</td>
      <td>20.75</td>
      <td>20.75</td>
      <td>L</td>
      <td>Chicken</td>
      <td>Chicken, Tomatoes, Red Peppers, Red Onions, Ja...</td>
      <td>The Southwest Chicken Pizza</td>
    </tr>
    <tr>
      <th>48615</th>
      <td>48616</td>
      <td>21348</td>
      <td>ckn_alfredo_m</td>
      <td>1</td>
      <td>2015-12-31</td>
      <td>21:23:10</td>
      <td>16.75</td>
      <td>16.75</td>
      <td>M</td>
      <td>Chicken</td>
      <td>Chicken, Red Onions, Red Peppers, Mushrooms, A...</td>
      <td>The Chicken Alfredo Pizza</td>
    </tr>
    <tr>
      <th>48616</th>
      <td>48617</td>
      <td>21348</td>
      <td>four_cheese_l</td>
      <td>1</td>
      <td>2015-12-31</td>
      <td>21:23:10</td>
      <td>17.95</td>
      <td>17.95</td>
      <td>L</td>
      <td>Veggie</td>
      <td>Ricotta Cheese, Gorgonzola Piccante Cheese, Mo...</td>
      <td>The Four Cheese Pizza</td>
    </tr>
    <tr>
      <th>48617</th>
      <td>48618</td>
      <td>21348</td>
      <td>napolitana_s</td>
      <td>1</td>
      <td>2015-12-31</td>
      <td>21:23:10</td>
      <td>12.00</td>
      <td>12.00</td>
      <td>S</td>
      <td>Classic</td>
      <td>Tomatoes, Anchovies, Green Olives, Red Onions,...</td>
      <td>The Napolitana Pizza</td>
    </tr>
    <tr>
      <th>48618</th>
      <td>48619</td>
      <td>21349</td>
      <td>mexicana_l</td>
      <td>1</td>
      <td>2015-12-31</td>
      <td>22:09:54</td>
      <td>20.25</td>
      <td>20.25</td>
      <td>L</td>
      <td>Veggie</td>
      <td>Tomatoes, Red Peppers, Jalapeno Peppers, Red O...</td>
      <td>The Mexicana Pizza</td>
    </tr>
    <tr>
      <th>48619</th>
      <td>48620</td>
      <td>21350</td>
      <td>bbq_ckn_s</td>
      <td>1</td>
      <td>2015-12-31</td>
      <td>23:02:05</td>
      <td>12.75</td>
      <td>12.75</td>
      <td>S</td>
      <td>Chicken</td>
      <td>Barbecued Chicken, Red Peppers, Green Peppers,...</td>
      <td>The Barbecue Chicken Pizza</td>
    </tr>
  </tbody>
</table>
</div>




```python
print("The Metadataset:",df.shape)
```

    The Metadataset: (48620, 12)
    


```python
print("The Rows of the dataset:",df.shape[0])
```

    The Rows of the dataset: 48620
    


```python
print("The Columns of the dataset:",df.shape[1])
```

    The Columns of the dataset: 12
    


```python
df.columns
```




    Index(['pizza_id', 'order_id', 'pizza_name_id', 'quantity', 'order_date',
           'order_time', 'unit_price', 'total_price', 'pizza_size',
           'pizza_category', 'pizza_ingredients', 'pizza_name'],
          dtype='object')




```python
df.info
```




    <bound method DataFrame.info of        pizza_id  order_id  pizza_name_id  quantity order_date order_time  \
    0             1         1     hawaiian_m         1 2015-01-01   11:38:36   
    1             2         2  classic_dlx_m         1 2015-01-01   11:57:40   
    2             3         2  five_cheese_l         1 2015-01-01   11:57:40   
    3             4         2    ital_supr_l         1 2015-01-01   11:57:40   
    4             5         2     mexicana_m         1 2015-01-01   11:57:40   
    ...         ...       ...            ...       ...        ...        ...   
    48615     48616     21348  ckn_alfredo_m         1 2015-12-31   21:23:10   
    48616     48617     21348  four_cheese_l         1 2015-12-31   21:23:10   
    48617     48618     21348   napolitana_s         1 2015-12-31   21:23:10   
    48618     48619     21349     mexicana_l         1 2015-12-31   22:09:54   
    48619     48620     21350      bbq_ckn_s         1 2015-12-31   23:02:05   
    
           unit_price  total_price pizza_size pizza_category  \
    0           13.25        13.25          M        Classic   
    1           16.00        16.00          M        Classic   
    2           18.50        18.50          L         Veggie   
    3           20.75        20.75          L        Supreme   
    4           16.00        16.00          M         Veggie   
    ...           ...          ...        ...            ...   
    48615       16.75        16.75          M        Chicken   
    48616       17.95        17.95          L         Veggie   
    48617       12.00        12.00          S        Classic   
    48618       20.25        20.25          L         Veggie   
    48619       12.75        12.75          S        Chicken   
    
                                           pizza_ingredients  \
    0               Sliced Ham, Pineapple, Mozzarella Cheese   
    1      Pepperoni, Mushrooms, Red Onions, Red Peppers,...   
    2      Mozzarella Cheese, Provolone Cheese, Smoked Go...   
    3      Calabrese Salami, Capocollo, Tomatoes, Red Oni...   
    4      Tomatoes, Red Peppers, Jalapeno Peppers, Red O...   
    ...                                                  ...   
    48615  Chicken, Red Onions, Red Peppers, Mushrooms, A...   
    48616  Ricotta Cheese, Gorgonzola Piccante Cheese, Mo...   
    48617  Tomatoes, Anchovies, Green Olives, Red Onions,...   
    48618  Tomatoes, Red Peppers, Jalapeno Peppers, Red O...   
    48619  Barbecued Chicken, Red Peppers, Green Peppers,...   
    
                           pizza_name  
    0              The Hawaiian Pizza  
    1        The Classic Deluxe Pizza  
    2           The Five Cheese Pizza  
    3       The Italian Supreme Pizza  
    4              The Mexicana Pizza  
    ...                           ...  
    48615   The Chicken Alfredo Pizza  
    48616       The Four Cheese Pizza  
    48617        The Napolitana Pizza  
    48618          The Mexicana Pizza  
    48619  The Barbecue Chicken Pizza  
    
    [48620 rows x 12 columns]>



Data Types in Raw Data


```python
df.dtypes
```




    pizza_id                      int64
    order_id                      int64
    pizza_name_id                object
    quantity                      int64
    order_date           datetime64[ns]
    order_time                   object
    unit_price                  float64
    total_price                 float64
    pizza_size                   object
    pizza_category               object
    pizza_ingredients            object
    pizza_name                   object
    dtype: object




```python
df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>pizza_id</th>
      <th>order_id</th>
      <th>quantity</th>
      <th>order_date</th>
      <th>unit_price</th>
      <th>total_price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>48620.000000</td>
      <td>48620.000000</td>
      <td>48620.000000</td>
      <td>48620</td>
      <td>48620.000000</td>
      <td>48620.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>24310.500000</td>
      <td>10701.479761</td>
      <td>1.019622</td>
      <td>2015-06-29 11:03:43.611682560</td>
      <td>16.494132</td>
      <td>16.821474</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>2015-01-01 00:00:00</td>
      <td>9.750000</td>
      <td>9.750000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>12155.750000</td>
      <td>5337.000000</td>
      <td>1.000000</td>
      <td>2015-03-31 00:00:00</td>
      <td>12.750000</td>
      <td>12.750000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>24310.500000</td>
      <td>10682.500000</td>
      <td>1.000000</td>
      <td>2015-06-28 00:00:00</td>
      <td>16.500000</td>
      <td>16.500000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>36465.250000</td>
      <td>16100.000000</td>
      <td>1.000000</td>
      <td>2015-09-28 00:00:00</td>
      <td>20.250000</td>
      <td>20.500000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>48620.000000</td>
      <td>21350.000000</td>
      <td>4.000000</td>
      <td>2015-12-31 00:00:00</td>
      <td>35.950000</td>
      <td>83.000000</td>
    </tr>
    <tr>
      <th>std</th>
      <td>14035.529381</td>
      <td>6180.119770</td>
      <td>0.143077</td>
      <td>NaN</td>
      <td>3.621789</td>
      <td>4.437398</td>
    </tr>
  </tbody>
</table>
</div>


KPI'S

```python
total_revenue = df['total_price'].sum()
total_pizzas_sold = df['quantity'].sum()
total_orders = df['order_id'].nunique()

avg_order_value = total_revenue / total_orders
avg_pizzas_per_order = total_pizzas_sold / total_orders

print(f"Total Revenue: ${total_revenue:,.2f}")
print(f"Total Pizzas Sold: {total_pizzas_sold:,}")
print(f"Total Orders: {total_orders:,}")
print(f"Average Order Value: ${avg_order_value:,.2f}")
print(f"Average Pizzas per Order: {avg_pizzas_per_order:.2f}")
```

    Total Revenue: $817,860.05
    Total Pizzas Sold: 49,574
    Total Orders: 21,350
    Average Order Value: $38.31
    Average Pizzas per Order: 2.32
    
Chart's
Ingredient Analysis


```python
ingredient = (
    df['pizza_ingredients']
        .str.split(',')
        .explode()
        .str.strip()
        .value_counts()
        .reset_index(name='counts')
        .rename(columns={'index': 'Ingredients'})
)

print(ingredient.head(15))

```

        pizza_ingredients  counts
    0              Garlic   27422
    1            Tomatoes   26601
    2          Red Onions   19547
    3         Red Peppers   16284
    4   Mozzarella Cheese   10333
    5           Pepperoni   10300
    6             Spinach   10012
    7           Mushrooms    9624
    8             Chicken    8443
    9           Capocollo    6572
    10       Green Olives    6174
    11         Artichokes    5682
    12   Jalapeno Peppers    5643
    13      Green Peppers    5224
    14        Feta Cheese    4748
    

Daily Trend - Total Orders


```python
import matplotlib.pyplot as plt

# Convert to datetime
df['order_date'] = pd.to_datetime(df['order_date'], dayfirst=True)

# Extract day name
df['day_name'] = df['order_date'].dt.day_name()

# Correct weekday order (capitalized)
weekday_order = [
    'Monday', 'Tuesday', 'Wednesday',
    'Thursday', 'Friday', 'Saturday', 'Sunday'
]

# Convert to ordered categorical
df['day_name'] = pd.Categorical(
    df['day_name'],
    categories=weekday_order,
    ordered=True
)

# Calculate unique orders per day
orders_by_day = df.groupby('day_name', observed=False)['order_id'].nunique()

# Plot
ax = orders_by_day.plot(
    kind='bar',
    figsize=(8,5),
    color='green',
    edgecolor='black'
)

plt.title("Total Orders by Day of Week")
plt.xlabel("Day of Week")
plt.ylabel("Number of Orders")
plt.xticks(rotation=45)

# Add value labels on bars
for i, val in enumerate(orders_by_day):
    plt.text(i, val, str(val), ha='center', va='bottom')

plt.tight_layout()
plt.show()

```


    
![png](output_21_0.png)
    

Daily Trend - Total Revenue

```python
import matplotlib.pyplot as plt

# Convert to datetime
df['order_date'] = pd.to_datetime(df['order_date'], dayfirst=True)

# Extract day name
df['day_name'] = df['order_date'].dt.day_name()

# Correct weekday order
weekday_order = [
    'Monday', 'Tuesday', 'Wednesday',
    'Thursday', 'Friday', 'Saturday', 'Sunday'
]

df['day_name'] = pd.Categorical(
    df['day_name'],
    categories=weekday_order,
    ordered=True
)

# Calculate total revenue per day
orders_by_day = df.groupby('day_name', observed=False)['total_price'].sum()

# Plot
ax = orders_by_day.plot(
    kind='bar',
    figsize=(8,5),
    color='purple',   # fixed here
    edgecolor='black'
)

plt.title("Total Revenue by Day of Week")
plt.xlabel("Day of Week")
plt.ylabel("Total Revenue")
plt.xticks(rotation=45)

# Add formatted revenue labels
for i, val in enumerate(orders_by_day):
    plt.text(i, val, f"${val:,.0f}", ha='center', va='bottom')

plt.tight_layout()
plt.show()

```


    
![png](output_23_0.png)
    

Hourly Trend - Total orders

```python
import matplotlib.pyplot as plt
import pandas as pd

# Convert to datetime
df['order_time'] = pd.to_datetime(df['order_time'], format='%H:%M:%S')

# Extract hour
df['order_hour'] = df['order_time'].dt.hour

# Count unique orders per hour
orders_by_hour = df.groupby('order_hour')['order_id'].nunique()

# Plot
ax = orders_by_hour.plot(
    kind='bar',
    figsize=(10,5),
    color='maroon',
    edgecolor='black'
)

plt.title("Total Orders by Hour of Day")
plt.xlabel("Hour of Day (24-hour format)")
plt.ylabel("Number of Orders")
plt.xticks(rotation=0)

# Add labels on top of bars
for i, val in enumerate(orders_by_hour):
    plt.text(i, val + 2, str(val), ha='center',va='bottom',fontsize=9, fontweight='bold')  # small offset for visibility

plt.tight_layout()
plt.show()

```


    
![png](output_25_0.png)
    

Monthly Trend - Total Orders

```python
import matplotlib.pyplot as plt
import pandas as pd

# Convert to datetime
df['order_date'] = pd.to_datetime(df['order_date'], dayfirst=True)

# Extract month name
df['month_name'] = df['order_date'].dt.month_name()

# Correct month order (capitalized)
month_order = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
]

# Convert to ordered categorical
df['month_name'] = pd.Categorical(
    df['month_name'],
    categories=month_order,
    ordered=True
)

# Count unique orders per month
orders_by_month = df.groupby('month_name', observed=False)['order_id'].nunique()

# Plot
plt.figure(figsize=(10,5))

plt.fill_between(
    range(len(orders_by_month)),
    orders_by_month.values,
    color="blue",
    alpha=0.6
)

plt.plot(
    range(len(orders_by_month)),
    orders_by_month.values,
    color="black",
    linewidth=2,
    marker="o"
)

plt.title("Total Orders by Month")
plt.xlabel("Month")
plt.ylabel("Number of Orders")
plt.xticks(range(len(orders_by_month)), orders_by_month.index, rotation=45)

# Add value labels
for i, val in enumerate(orders_by_month):
    plt.text(i, val + 10, str(val),
             ha="center", va="bottom",
             fontsize=9, fontweight="bold")

plt.tight_layout()
plt.show()

```


    
![png](output_27_0.png)
    

% of Sales by Category

```python
import matplotlib.pyplot as plt

# Total sales by category
category_sales = df.groupby("pizza_category")["total_price"].sum()

# Percentage calculation
category_pct = (category_sales / category_sales.sum()) * 100

plt.figure(figsize=(7,7))

colors = plt.get_cmap('tab20').colors

plt.pie(
    category_pct,
    labels=category_pct.index,
    autopct='%1.1f%%',
    startangle=90,
    colors=colors,
    wedgeprops={
        'edgecolor': 'black',
        'width': 0.4   # makes it a donut chart
    }
)

plt.title("Percentage of Sales by Pizza Category")

plt.tight_layout()
plt.show()

```


    
![png](output_29_0.png)
    

% Sales by Pizza Size & Category

```python
import seaborn as sns
import matplotlib.pyplot as plt

# Create pivot table
sales_pivot = df.pivot_table(
    index="pizza_category",
    columns="pizza_size",
    values="total_price",
    aggfunc="sum",
    fill_value=0
)

# Convert to percentage of total sales
sales_pct = (sales_pivot / sales_pivot.sum().sum()) * 100

# Plot heatmap
plt.figure(figsize=(10,6))

sns.heatmap(
    sales_pct,
    annot=True,
    fmt=".1f",
    cmap="YlOrRd",
    linewidths=0.5
)

plt.title("% of Sales by Pizza Category and Size")
plt.ylabel("Pizza Category")
plt.xlabel("Pizza Size")

plt.tight_layout()
plt.show()

```


    
![png](output_31_0.png)
    

Total Pizza Sold by Pizza Category

```python
# Group and sum quantity
pizzas_by_category = df.groupby("pizza_category")['quantity'].sum()

# Plot
ax = pizzas_by_category.plot( kind='bar',figsize=(8,5), color='skyblue', edgecolor='black')

plt.title("Total Pizzas Sold by Pizza Category")
plt.xlabel("Pizza Category")
plt.ylabel("Total Pizzas Sold")
plt.xticks(rotation=45)

# Add value labels
for i, val in enumerate(pizzas_by_category):
    plt.text(i, val + 5, str(val), ha="center", va="bottom", fontsize=9, fontweight="bold")

plt.tight_layout()
plt.show()

```


    
![png](output_33_0.png)
    

Top 5 Best Selling Pizzas = Total Qty

```python
import matplotlib.pyplot as plt

# Group by pizza name and sum quantity
pizzas_by_name = df.groupby("pizza_name")["quantity"].sum()

# Get top 5
top5 = pizzas_by_name.sort_values(ascending=False).head(5)

# Plot
ax = top5.plot(
    kind="bar",
    figsize=(8,5),
    color="grey",
    edgecolor="black"
)

plt.title("Top 5 Pizzas Sold")
plt.xlabel("Pizza Name")
plt.ylabel("Total Pizzas Sold")
plt.xticks(rotation=45)

# Add value labels
for i, val in enumerate(top5):
    plt.text(i, val + 2, str(val),
             ha="center", va="bottom",
             fontsize=9, fontweight="bold")

plt.tight_layout()
plt.show()

```


    
![png](output_35_0.png)
    

Top 5 Best Selling Pizzas = Total Orders

```python
import matplotlib.pyplot as plt

# Group by pizza name and sum quantity
pizzas_by_name = df.groupby("pizza_name")["quantity"].sum()

# Get top 5
top5 = pizzas_by_name.sort_values(ascending=False).head(5)

# Plot
ax = top5.plot(
    kind="bar",
    figsize=(8,5),
    color="purple",
    edgecolor="black"
)

plt.title("Top 5 Pizzas Sold")
plt.xlabel("Pizza Name")
plt.ylabel("Total Pizzas Sold")
plt.xticks(rotation=45)

# Add value labels
for i, val in enumerate(top5):
    plt.text(i, val + 2, str(val),
             ha="center", va="bottom",
             fontsize=9, fontweight="bold")

plt.tight_layout()
plt.show()

```


    
![png](output_37_0.png)
    


Top 5 Best-Selling Pizzas - Total Sales


```python
import matplotlib.pyplot as plt

# Group by pizza name and sum quantity
pizzas_by_name = df.groupby("pizza_name")["total_price"].sum()

# Get top 5
top5 = pizzas_by_name.sort_values(ascending=False).head(5)

# Plot
ax = top5.plot(
    kind="bar",
    figsize=(8,5),
    color="grey",
    edgecolor="black"
)

plt.title("Top 5 Pizzas by Revenue")
plt.xlabel("Pizza Name")
plt.ylabel("Total Pizzas Sold")
plt.xticks(rotation=45)

# Add value labels
for i, val in enumerate(top5):
    plt.text(i, val + 2, str(val),
             ha="center", va="bottom",
             fontsize=9, fontweight="bold")

plt.tight_layout()
plt.show()

```


    
![png](output_39_0.png)
    

Bottom 5 Best-Selling Pizzas - Total Sales

```python
import matplotlib.pyplot as plt

# Group by pizza name and sum quantity
pizzas_by_name = df.groupby("pizza_name")["quantity"].sum()

# Get bottom 5
bottom5 = pizzas_by_name.sort_values(ascending=True).head(5)

# Plot
ax = bottom5.plot(
    kind='bar',
    figsize=(8,5),
    color='skyblue',
    edgecolor='black'
)

plt.title("Bottom 5 Pizzas Sold")
plt.xlabel("Pizza Name")
plt.ylabel("Total Revenue")
plt.xticks(rotation=45)

# Add value labels
for i, val in enumerate(bottom5):
    plt.text(i, val + 1, str(val),
             ha="center", va="bottom",
             fontsize=9, fontweight="bold")

plt.tight_layout()
plt.show()

```


    
![png](output_41_0.png)
    



```python

```
